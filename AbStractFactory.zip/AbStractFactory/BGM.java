package AbStractFactory;

abstract class BGM {                   //背景音乐  
	public abstract void playMusic();  //播放背景音乐
}
