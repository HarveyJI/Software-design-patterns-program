package AbStractFactory;

public class BGM_Classical extends BGM{        //经典音乐

	public void playMusic() {
			System.out.println("播放古典音乐");
	}

}
