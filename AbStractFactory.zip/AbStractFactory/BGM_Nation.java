package AbStractFactory;

public class BGM_Nation extends BGM{             //民族音乐 
	public void playMusic() {
		System.out.println("播放民族音乐");
}
}
