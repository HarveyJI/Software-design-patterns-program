package AbStractFactory;

abstract class Buidings {                    //建筑
	public abstract void creatingBuidings(); //建造建筑
}
