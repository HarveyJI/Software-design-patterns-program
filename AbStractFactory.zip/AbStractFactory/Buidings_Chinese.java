package AbStractFactory;

public class Buidings_Chinese extends Buidings{    //中式建筑
	public void creatingBuidings() {
		System.out.println("建造中式建筑");
	}
}
