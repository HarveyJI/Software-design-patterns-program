package AbStractFactory;

public class Buidings_European extends Buidings{     //欧式建筑

	public void creatingBuidings() {
		System.out.println("建造欧式建筑");
	}

}
