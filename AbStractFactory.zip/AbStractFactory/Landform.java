package AbStractFactory;

abstract class Landform {            //地形
	public abstract void generateLandform();  //生成地形
}
