package AbStractFactory;

public class Landform_Mountainous extends Landform{   //山地

	public void generateLandform() {
		System.out.println("生成山地地形");
	}
}
