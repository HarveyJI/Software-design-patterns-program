package AbStractFactory;

public class Landform_Plain extends Landform{      //平原

	public void generateLandform() {
		System.out.println("生成平原地形");
	}

}
