package Adapter;

public interface Renminbi  {         //目标角色---使用人民币消费
	public void Renminbiconsume(int money);	  //人民币消费方法
}
