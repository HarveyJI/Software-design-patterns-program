package Facade;

public class AudioSubsystem {           //音频子系统
		public void audioOutput() {
			System.out.println("音频开始输出...");
		}
		public void audioClose() {
			System.out.println("...音频关闭");
		}
}
