package Facade;

public class LyricSubsystem {          //歌词子系统
	public void lyricOpen() {
		System.out.println("歌词已打开...");
	}
	public void lyricClose() {
		System.out.println("...歌词已关闭");
	}
	
}
