package Facade;

public abstract class PlayerAbFacade {          //抽象播放外观类
	abstract void start();               //播放方法
	abstract void stop();                //关闭方法
}

