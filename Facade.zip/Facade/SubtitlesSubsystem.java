package Facade;

public class SubtitlesSubsystem {               //字幕子系统
	public void subtitleOpen() {
		System.out.println("字幕已打开...");
	}
	public void subtitleClose() {
		System.out.println("...字幕关闭");
	}
}
