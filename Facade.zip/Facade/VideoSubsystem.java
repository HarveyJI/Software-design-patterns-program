package Facade;

public class VideoSubsystem {             //视频子系统
	public void screenOutput() {
		System.out.println("画面开始输出...");
	}
	public void screenClose() {
		System.out.println("...画面关闭");
	}
}
