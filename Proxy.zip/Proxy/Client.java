package Proxy;

public class Client {      //客户端

	public static void main(String[] args) {

		Web web=new WebVPN();
		web.requset();
	}
}
