package Proxy;

abstract class Web {    //抽象主题
	public abstract void requset(); //浏览网页
}
