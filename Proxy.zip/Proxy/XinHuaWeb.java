package Proxy;

public class XinHuaWeb extends Web{     //真实主题
	
	public  void requset() {   //浏览网页新华教务系统
		System.out.println("正在浏览新华教务系统...");
	} 
}
