package SimpleFactory;

public class AppleLogin implements Login{ //苹果登陆类

	public void logging(String account) {
		System.out.println("苹果登陆--->账号:" + account);
	}                         
	
}
