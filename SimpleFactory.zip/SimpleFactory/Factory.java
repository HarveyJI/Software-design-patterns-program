package SimpleFactory;

public class Factory {        //工厂类 工具输入生成对应支付类子类对象
		
	public static Login product_who(String account) {
		 if(account.equals("支付宝")) {           
			    return (new AliLogin());
			 }else if(account.equals("微信") ){   
			    return (new WechatLogin());
			 }else if(account.equals("QQ")) {
			    return (new QQLogin());
			 }else if(account.equals("苹果")) {
				    return (new AppleLogin());
				 }
		return null;
	 }	
}
	
