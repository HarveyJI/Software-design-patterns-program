package SimpleFactory;

public interface Login {                 //父类 支付类
	 public void logging(String account);
}
