package SimpleFactory;

public class QQLogin implements Login{ //扣扣登陆类
	
	public void logging(String account) {
		System.out.println("扣扣登陆--->账号:" + account);
	}                    
	
}
