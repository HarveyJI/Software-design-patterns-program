package SimpleFactory;

public class WechatLogin implements Login{//微信登陆类

	public void logging(String account) {
		System.out.println("微信登陆--->账号:" + account);
		
	}                 
	
}
