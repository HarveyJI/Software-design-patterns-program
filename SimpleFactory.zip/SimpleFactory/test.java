package SimpleFactory;
import java.util.Scanner;

public class test {                              //测试类

	public static void main(String[] args) {
		Scanner sc= new Scanner(System.in);
		
	while(true) {
		System.out.println("请输入登陆方式:");
		String type_Login=sc.next();
		String account="Harvey";
		
		Login log = Factory.product_who(type_Login);     //通过工厂以及输入登陆方式生成对应对象
		if(log!=null) {//调用方法输出
			log.logging(account);
		}else {
			System.out.println("登陆方式非法!---请检查!!!");
		}
		
	}
		
		     	                     
		                    
	}
}

